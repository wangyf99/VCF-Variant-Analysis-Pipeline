# VCF Variant QC & Statistical Analysis Pipeline

A Python pipeline for parsing, storing, and statistically analyzing genomic variant data in VCF format, with a focus on clinically significant variants relevant to neurodevelopmental conditions including Autism Spectrum Disorder (ASD).

## Motivation

Building on prior work estimating [13 statistically significant risk factors of ASD](https://doi.org/10.1192/j.eurpsy.2025.10071) from 3M+ health records, this project extends that analysis into the genomics domain — parsing ClinVar VCF data to identify variant-level patterns associated with pathogenic outcomes using standard genomic QC and statistical testing.

## Features

- **VCF parsing** via `cyvcf2` — handles plain and gzipped `.vcf.gz` files
- **SQLite storage** — variants indexed by chromosome and clinical significance for fast querying
- **Genomic QC metrics** — Ti/Tv ratio, variant type breakdown (SNP/INDEL/MNP), allele frequency distributions
- **Statistical testing** — chi-square enrichment test for pathogenic variants across chromosomes
- **Visualization** — chromosome-level variant maps, ClinVar significance pie chart, QUAL score histograms

## Quickstart

```bash
# 1. Clone and install
git clone https://github.com/YOUR_USERNAME/vcf-variant-pipeline.git
cd vcf-variant-pipeline
pip install -r requirements.txt

# 2. Download ClinVar VCF (GRCh38, ~600MB compressed)
mkdir -p data
curl -O --output-dir data \
  https://ftp.ncbi.nlm.nih.gov/pub/clinvar/vcf_GRCh38/clinvar.vcf.gz

# 3. Parse and store
python src/vcf_parser.py data/clinvar.vcf.gz

# 4. Run QC summary
python src/qc_stats.py

# 5. Generate figures
python src/visualize.py
```

## Data

**Source:** [NCBI ClinVar](https://www.ncbi.nlm.nih.gov/clinvar/) — public domain, no authentication required.  
**Format:** VCF 4.1 (GRCh38 genome build)  
**Size:** ~900K variants (full ClinVar)

> Raw VCF and database files are excluded from this repo via `.gitignore`.  
> Download instructions are in the Quickstart above.

## Methods

| Step | Tool / Method |
|---|---|
| VCF parsing | `cyvcf2` streaming parser |
| Storage | SQLite via `sqlite3` (indexed on `chrom`, `clnsig`) |
| Ti/Tv ratio | Computed from SNP-only subset |
| Enrichment test | Chi-square (`scipy.stats.chi2_contingency`) on pathogenic variant distribution across chromosomes |
| Visualization | `matplotlib`, `seaborn` |

## Key Outputs

| File | Description |
|---|---|
| `data/variants.db` | SQLite DB with all parsed variants |
| `outputs/variant_types.png` | SNP / insertion / deletion breakdown |
| `outputs/clnsig_distribution.png` | ClinVar significance pie chart |
| `outputs/variants_by_chrom.png` | Per-chromosome count, colored by % pathogenic |
| `outputs/qual_distribution.png` | QUAL score histogram |

## Project Structure

```
vcf-variant-pipeline/
├── data/               # Downloaded VCF + generated SQLite DB (gitignored)
├── notebooks/          # Jupyter walkthrough (coming soon)
├── outputs/            # Generated figures
├── src/
│   ├── vcf_parser.py   # VCF → SQLite
│   ├── qc_stats.py     # QC metrics + statistical tests
│   └── visualize.py    # Figure generation
├── requirements.txt
└── README.md
```

## Publication

Wang, Y., Zaks, N., Kodesh, A., et al. (2025). Maternal medication use in pregnancy and offspring ASD risk: A prescription-wide, target-informed study. *European Psychiatry*, 68(1), e125. https://doi.org/10.1192/j.eurpsy.2025.10071

## License

MIT
